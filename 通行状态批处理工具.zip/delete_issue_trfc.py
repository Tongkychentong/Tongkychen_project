import os
import sqlite3
import time
import argparse
import pandas as pd

curtime = str(time.strftime('%m-%d %H:%M:%S',time.localtime(time.time())))
curtime = curtime.replace(' ', '__')
curtime = curtime.replace(':', '-')
if getattr(os.sys, 'frozen', False):
    absPath = os.path.dirname(os.path.abspath(os.sys.executable))
elif __file__:
    absPath = os.path.dirname(os.path.abspath(__file__))


def get_all_files(file_path,file_list,file_filter=".sq3"):
    for file_name in os.listdir(file_path):
        file = os.path.join(file_path,file_name)
        if os.path.isdir(file):
            get_all_files(file,file_list,file_filter)
        else:
            if os.path.basename(file).endswith(file_filter) :
                # print(file)
                file_list.append(file)

def gettableinfo(cur=sqlite3.Cursor):
    cur.execute("SELECT name from sqlite_master WHERE TYPE = 'table'")
    table_info = []
    for row in cur.fetchall():
        table_info.append(row[0])
    return table_info

def check_column_exists(cursor=sqlite3.Cursor,table_name=str(), column_name=str()):
    cursor.execute("PRAGMA table_info({})".format(table_name))
    columns = [column[1].upper() for column in cursor.fetchall()]
    # print(table_name,column_name,columns,column_name)

    return column_name in columns

def diskSpaceCheck(dir):
    info = os.statvfs(dir)
    free_size = info.f_bsize * info.f_bavail / 1024 / 1024 / 1024
    # print(f'{dir}可用磁盘空间:{round(free_size, 3)}G')
    return round(free_size, 3)


def adds_table(table,Columns,values,add_data,main_cur=sqlite3.Cursor):
    # print('新增数据',table,idsCODES(add_data))
    sql = "INSERT INTO {} ( {} ) VALUES ( {} )".format(table,Columns,values)
    # print(sql)
    # values = [(item['field1'], item['field2'], item['field3']) for item in data]
    main_cur.executemany(sql, add_data)

def getColumns(Columns):
    # Columns = (('PCINF_ID', None, None, None, None, None, None), ('FEATURE_ID', None, None, None, None, None, None), ('ISSUE_TYPE', None, None, None, None, None, None), ('PCINF_TYPE', None, None, None, None, None, None))
    nameArr = []
    for y in Columns:
        nameArr.append(y[0]) 
        # print(nameArr)
    return nameArr
def ColumnsCODES(data):
    REST = ""
    RESTINDEX = -1
    for y in data:
        RESTINDEX += 1
        if RESTINDEX != 0:
            REST = REST + ','
        REST = REST + y 
   # print(REST)
    return REST

def valuesCODES(data):
    REST = ""
    RESTINDEX = -1
    for y in data:
        RESTINDEX += 1
        if RESTINDEX != 0:
            REST = REST + ','
        REST = REST + '?'
   # print(REST)
    return REST

PatchInfo = "\
CREATE TABLE [PatchInfo](\
PCINF_ID BIGINT,\
ISSUE_ID char(60),\
NODD_ID BIGINT, \
NODD_TYPE INTEGER,\
TILE INTEGER,\
ISSUE_TYPE char(20),\
PCINF_TYPE INTEGER,\
LAYER INTEGER,\
FEATURE_ID Bigint,\
FIELD char(10),\
OLD_VALUE char(100),\
NEW_VALUE char(20),\
SOFFSET INTEGER,\
EOFFSET INTEGER,\
CREATTIME char(20),\
UPDATETIME CHAR(20),\
VD_VERSION char(20),\
FM_VERSION char(60),\
PB_TIME char(20),\
ACCURACY INT DEFAULT 0,\
MEMO char(160) DEFAULT '',\
GEOMETRY BLOB\
);\
"
DefectInfo = "\
CREATE TABLE [DefectInfo](\
DFT_ID BIGINT,\
ISSUE_ID char(60),\
TILE INTEGER,\
STATUS INTEGER,\
TIME char(160),\
TYPE char(20),\
LAYER INTEGER,\
ID BIGINT,\
SOFFSET INTEGER,\
EOFFSET INTEGER,\
CREATTIME char(20),\
UPDATETIME char(20),\
VD_VERSION char(20),\
FM_VERSION char(60),\
PB_TIME CHAR(20),\
MEMO char(160) DEFAULT '',\
GEOMETRY BLOB\
);\
"
config = "CREATE TABLE [geometry_columns](\
[f_table_name] TEXT NULL, \
[f_geometry_column] TEXT NULL,\
[geometry_type] INTEGER NOT NULL,\
[coord_dimension] INTEGER NOT NULL,\
[srid] INTEGER NOT NULL,\
[spatial_index_enabled] INTEGER NOT NULL);\
"

def suplist(data):
    li = []
    if len(data) == 0:
        return []
    for row in data:
        li.append(row[0])
    return li


def getIssueRc(file_path,tile_id,issue_id,base_file=""):
        allroad = []
        conn = sqlite3.connect(file_path)
        conn.text_factory = lambda x : str(x, 'gbk', 'ignore')
        cur = conn.cursor()
        cur.execute(f"delete from PatchInfo where ISSUE_ID != '{issue_id}'")

        # 获取车道边线补丁
        sqllm = "select FEATURE_ID from PatchInfo where layer = 3 group by FEATURE_ID"
        cur.execute(sqllm)
        lmdata = cur.fetchall()
        if len(lmdata) >= 1:
            data = suplist(lmdata)
            slq = f"select R_ID from LaneMarking where LM_ID IN ({','.join(map(str, data))})"
            # print(slq)
            cur.execute(slq)
            data = cur.fetchall()
            for row in data:
                rids = row[0].split("|")
                for id in rids:
                    if id != "" and id is not None and id not in allroad:
                        allroad.append(id)
        
        
        # 获取车道补丁id
        sqllm = "select FEATURE_ID from PatchInfo where layer = 2 group by FEATURE_ID"
        cur.execute(sqllm)
        ldata = cur.fetchall()
        if len(ldata) >= 1:
            data = suplist(ldata)
            cur.execute(f"select R_ID from Lane WHERE L_ID IN ({','.join(map(str, data))})")
            data = cur.fetchall()
            for row in data:
                id = row[0]
                if str(id) != "" and str(id) is not None and str(id) not in allroad:
                    allroad.append(str(id))
                    
        # 获取道路补丁id
        sqllm = "select FEATURE_ID from PatchInfo where layer = 1 group by FEATURE_ID"
        cur.execute(sqllm)
        rids = suplist(cur.fetchall())
        for id in rids:
            if str(id) not in allroad:
              allroad.append(str(id))
        # print(filename,len(allroad))
               
        # 获取限速补丁id
        sqllm = "select FEATURE_ID from PatchInfo where layer = 14 group by FEATURE_ID"
        cur.execute(sqllm)
        ldata = cur.fetchall()
        if len(ldata) >= 1:
            # print('限速',filename)
            data = suplist(ldata)
            cur.execute(f"select R_ID from RestrictionLine WHERE RES_LN_ID IN ({','.join(map(str, data))})")
            data = cur.fetchall()
            for row in data:
                id = row[0]
                if str(id) != "" and str(id) is not None and str(id) not in allroad:
                    allroad.append(str(id))
                    
        # 获取类型补丁
        sqllm = "select FEATURE_ID from PatchInfo where layer = 4 group by FEATURE_ID"
        cur.execute(sqllm)
        ldata = cur.fetchall()
        if len(ldata) >= 1:
            # print('类型',filename)
            data = suplist(ldata)
            cur.execute(f"select L_ID from LaneTypeInfo WHERE LTI_ID IN ({','.join(map(str, data))})")
            data = cur.fetchall()
            data = suplist(data)
            if len(data) >= 1:
                cur.execute(f"select R_ID from Lane WHERE L_ID IN ({','.join(map(str, data))})")
                data = cur.fetchall()
                for row in data:
                    id = row[0]
                    if str(id) != "" and str(id) is not None and str(id) not in allroad:
                     allroad.append(str(id))
           
        # 宽度
        sqllm = "select FEATURE_ID from PatchInfo where layer = 16 group by FEATURE_ID"
        cur.execute(sqllm)
        ldata = cur.fetchall()
        if len(ldata) >= 1:
            # print('宽度',filename)
            data = suplist(ldata)
            cur.execute(f"select L_ID from LaneWidthInfo WHERE LWI_ID IN ({','.join(map(str, data))})")
            data = cur.fetchall()
            data = suplist(data)
            if len(data) >= 1:
                cur.execute(f"select R_ID from Lane WHERE L_ID IN ({','.join(map(str, data))})")
                data = cur.fetchall()
                for row in data:
                    id = row[0]
                    if str(id) != "" and str(id) is not None and str(id) not in allroad:
                        allroad.append(str(id))   
        #  5 分离合并
        sqllm = "select FEATURE_ID from PatchInfo where layer = 5 group by FEATURE_ID"
        cur.execute(sqllm)
        ldata = cur.fetchall()
        if len(ldata) >= 1:
            # print('分离合并',filename)
            data = suplist(ldata)
            cur.execute(f"select L_ID from LaneSplitMerge WHERE LSM_ID IN ({','.join(map(str, data))})")
            data = cur.fetchall()
            data = suplist(data)
            if len(data) >= 1:
                # print(f"select R_ID from Lane WHERE L_ID IN ({','.join(map(str, data))})")
                cur.execute(f"select R_ID from Lane WHERE L_ID IN ({','.join(map(str, data))})")
                data = cur.fetchall()
                for row in data:
                    id = row[0]
                    if str(id) != "" and str(id) is not None and str(id) not in allroad:
                        allroad.append(str(id)) 
        # 获取 obj 其他补丁
        obj_dict = {
            '6': 'JunctionArea',
            '7': 'RoadMark',
            '9': 'TrafficLight',
            '12': 'StopLine',
        }
        
        obj_filed_dict = {
            '6': 'JA_ID',
            '7': 'RM_ID',
            '9': 'TL_ID',
            '12': 'SL_ID',
        }
        for layer in obj_dict.keys():
            sqll = f"select FEATURE_ID from PatchInfo where layer = {layer} group by FEATURE_ID"
            layerName = obj_dict[layer]
            cur.execute(sqll) # REL_R_ID  
            ldata = cur.fetchall()
            if len(ldata) >= 1:
            # print('分离合并',filename)
                data = suplist(ldata)
                cur.execute(f"select REL_R_ID from {layerName} WHERE {obj_filed_dict[layer]} IN ({','.join(map(str, data))})")
                r_ids_data = cur.fetchall()
                for r_idsstr in r_ids_data:
                    r_ids1 = r_idsstr[0].split("*")
                    for r_idss in r_ids1:
                        r_ids = r_idss.split("|")
                        for r_id in r_ids:
                            if r_id != "" and r_id is not None and str(r_id) not in allroad:
                                allroad.append(str(r_id))

        
        cur.execute(f"select RC from Road where R_ID in ({','.join(map(str, allroad))}) group by RC")
        roadinfos = cur.fetchall()
        
        RCS = []
        for road in roadinfos:
            # print(road[0])
            RCS.append(road[0])
        # print(filename,cm_to_km_rounded(kml))
        
        
        if base_file != "" and base_file is not None and len(RCS) == 0:
            # 将工单补丁转移到基准
            sql1 = f"select * from PatchInfo"
            cur.execute(sql1)
            data1 = cur.fetchall()
            myColumns = getColumns(cur.description)
            baseconn = sqlite3.connect(base_file)
            # baseconn.text_factory = lambda x : str(x, 'gbk', 'ignore')
            basecur = baseconn.cursor()
            if len(data1):
                adds_table("PatchInfo",ColumnsCODES(myColumns),valuesCODES(myColumns),data1,basecur)
            baseconn.commit()
            baseconn.close()
            rc2 = getIssueRc(base_file,tile_id,issue_id)

            baseconn = sqlite3.connect(base_file)
            baseconn.text_factory = lambda x : str(x, 'gbk', 'ignore')
            basecur = baseconn.cursor()
            basecur.execute("delete from PatchInfo")
            baseconn.commit()
            baseconn.close()
            # print('rc2',rc2)
            for rc in rc2:
                RCS.append(rc)
        # if len(RCS) == 0 and base_file != "" and base_file is not None:
        #     print(tile_id,issue_id,len(RCS),len(allroad),base_file)
        conn.close()
        
        return RCS

def isGaosu(rcs=[]):
    gs = [0,6]
    for i in gs:
        if i in rcs:
            return True
    return False

configTable = "CREATE TABLE [geometry_columns](\
[f_table_name] TEXT NULL, \
[f_geometry_column] TEXT NULL,\
[geometry_type] INTEGER NOT NULL,\
[coord_dimension] INTEGER NOT NULL,\
[srid] INTEGER NOT NULL,\
[spatial_index_enabled] INTEGER NOT NULL);\
"

configTable = "CREATE TABLE [geometry_columns](\
[f_table_name] TEXT NULL, \
[f_geometry_column] TEXT NULL,\
[geometry_type] INTEGER NOT NULL,\
[coord_dimension] INTEGER NOT NULL,\
[srid] INTEGER NOT NULL,\
[spatial_index_enabled] INTEGER NOT NULL);\
"


PatchInfo = 'CREATE TABLE PatchInfo (\
    PCINF_ID BIGINT,\
    ISSUE_ID char(60), \
    NODD_ID BIGINT, \
    NODD_TYPE INTEGER,\
    TILE INTEGER,\
    ISSUE_TYPE char(20),\
    PCINF_TYPE INTEGER,\
    LAYER INTEGER,\
    FEATURE_ID Bigint,\
    FIELD char(10),\
    OLD_VALUE char(100),\
    NEW_VALUE char(20),\
    SOFFSET INTEGER,\
    EOFFSET INTEGER,\
    CREATTIME char(20),\
    UPDATETIME CHAR(20),\
    VD_VERSION char(20),\
    FM_VERSION char(60),\
    PB_TIME char(20),\
    ACCURACY INT DEFAULT 0,\
    MEMO char(160) DEFAULT "",\
    GEOMETRY BLOB\
);'

def adds_table(table,Columns,values,add_data,main_cur=sqlite3.Cursor):
    # print('新增数据',table,idsCODES(add_data))
    sql = "INSERT INTO {} ( {} ) VALUES ( {} )".format(table,Columns,values)
    # print(sql)
    # values = [(item['field1'], item['field2'], item['field3']) for item in data]
    main_cur.executemany(sql, add_data)
    
def get_latest_file(directory):
    latest_file = None
    latest_time = ""
    for name in os.listdir(directory):
        if name > latest_time:
            latest_time = name
            latest_file = os.path.join(directory, name)
    return latest_file
def createConfig(cursorOut):
    cursorOut.execute(DefectInfo)
    cursorOut.execute(config)
    cursorOut.execute("INSERT INTO geometry_columns (f_table_name,f_geometry_column,geometry_type,coord_dimension,srid,spatial_index_enabled) VALUES ( 'DefectInfo','Geometry',1001,3,4326 ,0)")

def process(dataptath=str,file_path=str,LayerName=str):
    db_file_list = []
    get_all_files(dataptath,db_file_list,".sq3")
    jiras = [ ]
    sqlissue = ''
    number = 0
    objIdData = pd.read_excel(file_path)
    usersInfo = []
    for index,row in objIdData.iterrows():
        jiras.append((row['ISSUE_ID']))
        # print(row['ISSUE_ID'])

    for issue in jiras:
        number+=1
        sqlissue += f"ISSUE_ID LIKE '%{issue}%'"
        if number != len(jiras):
            sqlissue += ' OR '
    for db_file in db_file_list:
        filename, ext = os.path.splitext(os.path.basename(db_file))
        if len(filename) != 9:
            print("不是图幅号文件",filename)
            continue
        conn = sqlite3.connect(db_file)
        conn.text_factory = lambda x : str(x, 'gbk', 'ignore')
        cur = conn.cursor()
        sqlquery = f"select rowid,NODD_ID,LAYER,PCINF_TYPE,FIELD,NEW_VALUE,FEATURE_ID,OLD_VALUE FROM {LayerName} WHERE ({sqlissue}) and (LAYER = 2 and NODD_ID=1 and PCINF_TYPE in (1,4))"
        cur.execute(sqlquery)
        data = cur.fetchall()
        # if len(data) > 0:
        for row in data:
            rowid = row[0]
            NODD_ID = row[1]
            PCINF_TYPE = row[3]
            FIELD = row[4]
            NEW_VALUE = row[5]
            FEATURE_ID = row[6]
            OLD_VALUE = row[7]
            if PCINF_TYPE == 1:
                if FIELD != 'trfc_flg':
                    continue
                elif NEW_VALUE == '1':
                    continue
                else:
                    sql1 = f"delete from {LayerName} where rowid = {rowid}"
                    sql2 = f"update Lane set TRFC_FLG = {OLD_VALUE} where L_ID = {FEATURE_ID}"
                    cur.execute(sql1)
                    cur.execute(sql2)
                    print(f"更新数据 {filename}")
            elif PCINF_TYPE == 4:
                cur.execute(f"select rowid,T_DRCT from Lane where L_ID = {FEATURE_ID}")
                lane = cur.fetchone()
                if lane is None:
                    print(f"错误数据 {filename}l_id：{FEATURE_ID}")
                    continue
                if lane[1] != 1:
                    sql2 = f"update Lane set TRFC_FLG = 1 where L_ID = {FEATURE_ID}"
                    cur.execute(sql2)
                    print(f"更新数据 {filename}")
        
        conn.commit()
        conn.close()
    
     
def issueRcCheck(datapath):
    db_file_list = []
    db_file_dict = {}
    # 获取所有文件路径
    get_all_files(datapath,db_file_list,".sq3")
    for db_file in db_file_list:
        filename, ext = os.path.splitext(os.path.basename(db_file))
        db_file_dict[filename] = db_file
    
class MyException(Exception):
    pass

if __name__ == "__main__" :
    parser = argparse.ArgumentParser()
    parser.add_argument("--datapath",type=str,required=True)
    parser.add_argument("--filepath",type=str,required=True)
    args = parser.parse_args()
    if os.path.exists(args.filepath) == False:
        raise MyException(f"filepath不存在:{args.filepath}")
    process(args.datapath,args.filepath,"PatchInfo")
    
    
  
# --datapath 补丁数据      
# --basepath 基准数据      
# --startId 开始主键ID      
#  python3 getxinftu.py --datapath=/mnt/data2/uploadPath/tile/HD/HD_6_24_09_19_03_xformat_202410161619 --basepath=/mnt/data2/uploadPath/tile/HD/HD_6_24_09_19_03_xformat_202410161619 --outpath=/mnt/system/data/tool/data


# python3 delete_issue_trfc.py --datapath=/home/work/data/versionwork/6_24_09_19_03_xformat_202410161619_PatchInfo_DefectInfo_202504231448_pure --filepath=issue_trfc.xlsx